package com.ccis.ccisapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CcisappApplicationTests {

	@Test
	void contextLoads() {
	}

}

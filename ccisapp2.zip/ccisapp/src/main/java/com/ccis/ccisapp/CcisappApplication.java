package com.ccis.ccisapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CcisappApplication {

	public static void main(String[] args) {
		SpringApplication.run(CcisappApplication.class, args);
	}

}
